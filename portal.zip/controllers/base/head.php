<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head>
        <?php include 'controllers/base/meta.php' ?>
        <!-- Site Title -->
        <title>UEAB</title>
        <link rel="icon" type="image/png" href="assets/img/ruv/ruv0.png"/>
        <?php include 'controllers/base/css.php' ?>
        <?php include 'dbconn/dbconn.php' ?>
        <?php include 'admin/data/data.php' ?>
    </head>