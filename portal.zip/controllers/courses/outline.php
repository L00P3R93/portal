<div class="jq-tab-content" data-tab="3">
    <ul class="course-list">
        <li class="justify-content-between d-flex">
            <p>Introduction Lesson</p>
            <a class="primary-btn text-uppercase" href="#">View Details</a>
        </li>
        <li class="justify-content-between d-flex">
            <p>Basics of HTML</p>
            <a class="primary-btn text-uppercase" href="#">View Details</a>
        </li>
        <li class="justify-content-between d-flex">
            <p>Getting Know about HTML</p>
            <a class="primary-btn text-uppercase" href="#">View Details</a>
        </li>
        <li class="justify-content-between d-flex">
            <p>Tags and Attributes</p>
            <a class="primary-btn text-uppercase" href="#">View Details</a>
        </li>
        <li class="justify-content-between d-flex">
            <p>Basics of CSS</p>
            <a class="primary-btn text-uppercase" href="#">View Details</a>
        </li>
        <li class="justify-content-between d-flex">
            <p>Getting Familiar with CSS</p>
            <a class="primary-btn text-uppercase" href="#">View Details</a>
        </li>
        <li class="justify-content-between d-flex">
            <p>Introduction to Bootstrap</p>
            <a class="primary-btn text-uppercase" href="#">View Details</a>
        </li>
        <li class="justify-content-between d-flex">
            <p>Responsive Design</p>
            <a class="primary-btn text-uppercase" href="#">View Details</a>
        </li>
        <li class="justify-content-between d-flex">
            <p>Canvas in HTML 5</p>
            <a class="primary-btn text-uppercase" href="#">View Details</a>
        </li>

    </ul>
</div>