<div class="jq-tab-content active" data-tab="1">
    <?php echo get_specific_data($dbconn,'courses','course_id',$courseid,'descr'); ?>
</div>