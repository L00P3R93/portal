<?php
    header( "refresh:3;url=../login.php" );
    echo "<center><h2>Invalid Reset Code...User does not exist. Redirecting shortly!</h2></center>";
?>