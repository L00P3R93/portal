<?php
    error_reporting(0);
    session_start();
    require 'connection/dbconn.php';
    $user_name=$_SESSION['username'];
?>