<!DOCTYPE html>
<html lang="en-US" dir="ltr">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="This is a free online database Management System.">
    <meta name="author" content="taskD">
    <meta itemprop="name" content="DBMS - A Database Management System"/>
    <meta itemprop="description" content=" This is a free online database Management System."/>
    <meta name="twitter:site" content="#"/>
    <meta name="twitter:title" content="This is a free online database Management System.">
    <meta name="twitter:description" content=" This is a free online database Management System."/>
    <meta name="twitter:creator" content="taskD"/>
    <meta name="twitter:domain" content="#"/>
    <meta property="og:type" content="website"/> 
    <meta property="og:title" content="DBMS - A Database Management System"/>
    <meta property="og:description" content="This is a free online database Management System."/>
    <meta property="og:url" content="#"/>
    <meta property="og:site_name" content="Infismash - Creativity that inspires you"/>
    <meta property="og:see_also" content="#"/>