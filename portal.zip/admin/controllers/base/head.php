    <?php include 'controllers/base/meta-tags.php' ?>

    <title>UEAB - Panel</title>
    <!--
        Favicons
        =============================================
        -->
        <link rel="icon" type="image/png" href="assets/img/ruv/ruv0.png"/>
        
     <?php include 'controllers/base/css.php' ?>
     <?php include 'controllers/base/font.php' ?>
    <?php include 'data/data.php' ?>
    <?php include 'controllers/base/javascript.php' ?>
</head>