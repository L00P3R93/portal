<?php

$dbname = "ueab";
$dbhost = "localhost";
$dbpass = "";
$dbuser = "root";

$dbconn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname) or die("Oops! something went wrong!");

?>